
async def main():
    from functions.func import create_cf, create_cf_api, check_if_all_exists, get_me, \
        run_timer, refresh_trusted_rights
    from config import f_api, f_config, f_config, trusted_f, \
        victims_file, victims_exclusion, my_illnesses_file, \
        js_info, user_config_js, f_chats_config, Me, all_iris
    import os
    
    if not os.path.exists(f_api):
        create_cf_api(f_api)
        raise ValueError(f'Заполните файл с api > {f_api}')
    
    from loader import app
    from pyrogram.handlers import MessageHandler
    from pyrogram import filters
    
    await app.start()
    
    Me.me = await app.get_me()
    
    await app.stop()
    
    check_if_all_exists(f_config, trusted_f, victims_file, \
    victims_exclusion, my_illnesses_file, js_info, \
    user_config_js, f_chats_config, me = Me.me)
    refresh_trusted_rights(trusted_f)
    
    from storage.storage import Settings, me_inf, ctimer, cycle_timers
    
    Settings.refresh(f_config)
    Settings.correct()
    
    try:
        me_inf.refresh()
    except:
        pass
    
    await app.start()
    
    from handlers import app
    from handlers.autoheal import autoheal
    from handlers.passive_actions import periodically_do, lab_victims_get, auto_zar_detecive
    from handlers.refresh_me_info import user_update_every_30_minute
    
    # Timers
    timer_1 = timer_2 = timer_3 = timer_4 = timer_5 = timer_6 = timer_7 = timer_8 = None
    if ctimer.timer_1:
        timer_1 = asyncio.create_task(run_timer(app, int(ctimer.timer_1['delay']), ctimer.timer_1['job'], ctimer.timer_1['chat']['id']))
        cycle_timers['timer_1'] = timer_1
    if ctimer.timer_2:
        timer_2 = asyncio.create_task(run_timer(app, int(ctimer.timer_2['delay']), ctimer.timer_2['job'], ctimer.timer_2['chat']['id']))
        cycle_timers['timer_2'] = timer_2
    if ctimer.timer_3:
        timer_3 = asyncio.create_task(run_timer(app, int(ctimer.timer_3['delay']), ctimer.timer_3['job'], ctimer.timer_3['chat']['id']))
        cycle_timers['timer_3'] = timer_3
    if ctimer.timer_4:
        timer_4 = asyncio.create_task(run_timer(app, int(ctimer.timer_4['delay']), ctimer.timer_4['job'], ctimer.timer_4['chat']['id']))
        cycle_timers['timer_4'] = timer_4
    if ctimer.timer_5:
        timer_5 = asyncio.create_task(run_timer(app, int(ctimer.timer_5['delay']), ctimer.timer_5['job'], ctimer.timer_5['chat']['id']))
        cycle_timers['timer_5'] = timer_5
    if ctimer.timer_6:
        timer_6 = asyncio.create_task(run_timer(app, int(ctimer.timer_6['delay']), ctimer.timer_6['job'], ctimer.timer_6['chat']['id']))
        cycle_timers['timer_6'] = timer_6
    if ctimer.timer_7:
        timer_7 = asyncio.create_task(run_timer(app, int(ctimer.timer_7['delay']), ctimer.timer_7['job'], ctimer.timer_7['chat']['id']))
        cycle_timers['timer_7'] = timer_7
    if ctimer.timer_8:
        timer_8 = asyncio.create_task(run_timer(app, int(ctimer.timer_8['delay']), ctimer.timer_8['job'], ctimer.timer_8['chat']['id']))
        cycle_timers['timer_8'] = timer_8
    
    tasks = [
        periodically_do(),
        lab_victims_get(),
        auto_zar_detecive(app),
        user_update_every_30_minute(app)
    ]
    
    if Settings.autoheal:
        app.add_handler(MessageHandler(autoheal, filters.text & filters.user(all_iris) & filters.regex(r'заражению')), group = 102)

    print('Started!')

    await asyncio.gather(*tasks)


if __name__ == "__main__":
    from pyrogram.errors import MessageIdInvalid, RandomIdDuplicate
    import asyncio
    
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    loop.run_forever()

