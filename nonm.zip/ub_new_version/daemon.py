from pyrogram import Client

import os, configparser, time
cwd = os.getcwd()
abs_path = os.path.abspath(__file__).rpartition('/')[0]
systemd_path = '/etc/systemd/system'
f_api = f'{abs_path}/data/settings/api_config.ini'

fd_session = f'{abs_path}/sessions'


read = configparser.ConfigParser()
read.read(f_api)

api_id = int(read['api']['api_id'])
api_hash = read['api']['api_hash']
phone_number = read['api']['phone_number']

print(api_id, api_hash, phone_number)

app = Client(
    'ses',
    api_id, api_hash,
    phone_number = phone_number,
    workdir = fd_session
)

with app:
    me = app.get_me()

id = me.id
name = me.first_name
username = ('' if not me.username else '@' + me.username)
daemon = f'{systemd_path}/ubtg-{id}.service'
logname = os.getcwd().split('/')[2]

text = (
'[Unit]\n'
f'Description = {name} {username}\n'
'After=multi-user.target\n\n'

'[Service]\n'
'Type=simple\n'
f'User = {logname}\n'
f'Group = {logname}\n'
f'WorkingDirectory = {cwd}\n'
f'ExecStart = python3 {cwd}/app.py\n'
'Restart=on-failure\n'
'RestartSec=42s\n\n'

'[Install]\n'
'WantedBy=multi-user.target\n'
)

with open(daemon, 'w') as fw:
    fw.write(text)
with open('service.txt', 'w') as fw:
    fw.write(f'ubtg-{id}.service\n')

time.sleep(1)
os.system(f'systemctl daemon-reload && systemctl enable --now {daemon}')
os.system(f'chown {logname}:{logname} {fd_session}/ses.session')

print(name, daemon)
