import os, shutil, configparser

class Paths:
    paths = [
        'functions',
        'handlers',
        'media',
        'storage',
        'app.py',
        'config.py',
        'loader.py'
    ]

def check_exists_ub_path(dir: str, paths: list):
    return not any([d not in os.listdir(dir) for d in paths])

def del_all_files_dir(dir: str, paths: list, mode: str = 'one'):
    if mode == 'one':
        for d in os.listdir(dir):
            if d in paths and os.path.exists(dir+d):
                if os.path.isfile(dir+d):
                    os.remove(dir+d)
                else:
                    shutil.rmtree(dir+d)
    else:
        for d in os.listdir(dir):
            if d.isdigit():
                for d_ in os.listdir(d):
                    path_ = f'{dir}/{d}/{d_}'
                    if d_ in paths and os.path.exists(path_):
                        if os.path.isfile(path_):
                            os.remove(path_)
                        else:
                            shutil.rmtree(path_)

def copy_files(ub_path: str, dest_path: str, paths: list, mode: str = 'one'):
    if mode == 'one':
        for d in os.listdir(ub_path):
            if d in paths:
                if os.path.isfile(ub_path+d):
                    shutil.copy(ub_path+d, dest_path)
                else:
                    shutil.copytree(ub_path+d, dest_path+d)
    else:
        for d in os.listdir(ub_path):
            if d in paths:
                if os.path.isfile(ub_path+d):
                    for dst in os.listdir(dest_path):
                        if dst.isdigit():
                            shutil.copy(ub_path+d, dst+'/'+d)
                else:
                    for dst in os.listdir(dest_path):
                        if dst.isdigit():
                            shutil.copytree(ub_path+d, dst+'/'+d)

def change_ini_config(up_path: str, dest_path: str, mode: str = 'one'):
    read = configparser.ConfigParser()
    read1 = configparser.ConfigParser()
    ub_cf = f'{ub_path}data/settings/user_config.ini'
    dest_cf = f'{dest_path}data/settings/user_config.ini'
    if mode == 'one':
        read.read(dest_cf)
        read1.read(ub_cf)
        for key1, val1 in read1['user_settings'].items():
            if key1 not in read['user_settings'].keys():
                read.set('user_settings', key1, val1)
        with open(dest_cf, 'w') as f:
            read.write(f)
    else:
        read1.read(ub_cf)
        for d in os.listdir(dest_path):
            dest_cf = f'{d}/data/settings/user_config.ini'
            if d.isdigit() and os.path.exists(dest_path):
                read.read(dest_cf)
                for key1, val1 in read1['user_settings'].items():
                    if key1 not in read['user_settings'].keys():
                        read.set('user_settings', key1, val1)
                with open(dest_cf, 'w') as f:
                    read.write(f)

ub_path = input('Type ub path: ')
dest_path = input('Type destination path: ')
mode = input('Which one all/one: ').lower()

if ub_path[-1] != '/':
    ub_path = ub_path + '/'
if dest_path != '/' and dest_path != '.':
    dest_path = dest_path + '/'
if mode not in ['one', 'all']:
    raise SyntaxError('Mode must be one or all')

if check_exists_ub_path(ub_path, Paths.paths):
    del_all_files_dir(dest_path, Paths.paths, mode = mode)
    copy_files(ub_path, dest_path, Paths.paths, mode = mode)
    change_ini_config(ub_path, dest_path, mode = mode)
else:
    raise FileNotFoundError(f"Path {ub_path} doesn't have all files")
