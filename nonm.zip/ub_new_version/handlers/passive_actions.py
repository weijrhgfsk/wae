from config import f_config, Me, all_iris, black_iris, victims_file, victims_file_dump, victims_exclusion, \
    js_detective_storage, my_illnesses_file, \
    Style, StyleTexts, js_info, GlobalStack
from storage.storage import Settings, my_illnesses, JsRead, me_inf, VictimsEclusionRead
from functions import func
from loader import app

from pyrogram import Client, filters, enums
from pyrogram.errors import RandomIdDuplicate
from pyrogram.types import Message
from pyrogram.raw.functions.messages import SendReaction
from pyrogram.raw.types import InputPeerSelf, ReactionCustomEmoji
from datetime import datetime, timedelta

import asyncio, re, random, humanize, os, json, shutil

### Passive actions ###

## passive write enemy to zarlist ##
@app.on_message(filters.text & filters.user(all_iris) & filters.regex('заражению'), group = 103)
async def get_iris_enemy(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = msg.text.lower()
    entity = msg.chat.id
    
    if msg.entities and (re.findall(r'подвер[гла]+ заражению', msgtl) and '🗓 Отчёт об операции заражения объекта:' in msgt or re.findall(r'подвер[гла]+ заражению', msgtl.splitlines()[0])) and 'био-опыта' in msgtl:
        
        auto_plus = False
        
        # me
        me_url_mesg = func.tag_get(msg.entities[0].url)
        me_url = (Me.me.username if Me.me.username else str(Me.me.id))
        
        # Сравнение
        if me_url.lower() != me_url_mesg.lower():
            if Settings.autoanswer_chats.get(str(entity)) and Settings.autoanswer_chats[str(entity)].get('auto_infecter_chat') and Settings.autoanswer_chats[str(entity)]['auto_infecter_chat'] == 'True':
                auto_plus = True
            else:
                return
        
        # data
        id_enemy_name = None
        id_enemy, id_enemy_, us_enemy = None, None, None
        us_enemy, me_msg, random_infect = None, None, False
        exp_do = '0'
        
        # get name and exp from message text
        for inf_msg in msgt.splitlines():
            if '🦠' in inf_msg:
                name_enemy = re.split(r'подвер[гла]+ заражению (неизвестным патогеном |патогеном «.+» )', inf_msg)[-1]
            if '☣️' in inf_msg:
                exp = re.search(r'[\dk,]+', inf_msg)[0]
            if '🤒' in inf_msg:
                days = int(re.search(r'\d+', inf_msg)[0])
                z_date = datetime.today() + timedelta(days=days)
                ot_data = z_date.strftime("%d.%m.%Y")
        
        if not 'k' in exp and (int(exp) <= 5 or auto_plus and int(exp) < 75):
            return
        
        # parse entity
        if len(msg.entities) >= 2 and msg.entities[1].type == enums.MessageEntityType.TEXT_MENTION:
            id_enemy_ = str(msg.entities[1].user.id)
        else:
            search = func.zarlist_val_searcher(name_enemy, 'val', JsRead.js_read)
            if search:
                id_enemy_name = list(search)[0]
        
        async for msg_ in app.search_messages(chat_id = entity, limit = 12):
            if not msg_.text or not msg_.from_user: continue
            if msg_.id <= msg.id and 'заразить' in msg_.text.lower().splitlines()[0] and (me_url_mesg.isdigit() and str(msg_.from_user.id) == me_url_mesg or not me_url_mesg.isdigit() and msg_.from_user.username and msg_.from_user.username.lower() == me_url_mesg.lower()) and len(msg_.text.splitlines()) <= 2:
                if func.msg_check_tattack(msg_.text):
                    link = func.tag_get(msg_.text.lower())
                    if link.isdigit():
                        id_enemy = link
                    else:
                        us_enemy = link
                        db_check = await func.check_in_db(app, link, JsRead, victims_file, get_entity = True)
                        if db_check['instance']:
                            id_enemy = list(db_check['instance'])[0]
                elif [sym for sym in ['-', '=', '+'] if sym in msg_.text]:
                    random_infect = True
                    if id_enemy_name:
                        id_enemy = id_enemy_name
                    elif not id_enemy_:
                        return
                elif msg_.reply_to_message_id:
                    msgr_ = await app.get_messages(msg_.chat.id, msg_.reply_to_message_id)
                    if msgr_ and not msgr_.from_user.is_bot:
                        id_enemy = str(msgr_.from_user.id)
                        if msgr_.from_user.username:
                            us_enemy = msgr_.from_user.username
                if id_enemy_:
                    if id_enemy_ == id_enemy:
                        me_msg = msg_
                        break
                elif id_enemy:
                    me_msg = msg_
                    break
        
        if me_msg is None: return
        if id_enemy_: id_enemy = id_enemy_
        
        if JsRead.js_read.get(id_enemy):
            exp_do = JsRead.js_read[id_enemy].get('experience')
        
        exp_int = (float(exp.replace(',', '.').replace('k', '')) * 1000 if 'k' in exp else int(exp))
        
        # auto ex
        if Settings.auto_ex:
            if 'k' in Settings.auto_ex:
                exp_ex = int(float(Settings.auto_ex.replace('k', '')) * 1000)
            else:
                exp_ex = int(Settings.auto_ex)
            if exp_int >= exp_ex:
                if id_enemy not in VictimsEclusionRead.js_read:
                    func.victims_exclusion_append({id_enemy: {'name': name_enemy}}, victims_exclusion)
                VictimsEclusionRead.refresh()
        
        if auto_plus:
            exp_do = (float(exp_do.replace(',', '.').replace('k', '')) * 1000 if 'k' in exp_do else int(exp_do))
            chat_answer = msg.chat.id
            
            while GlobalStack.stop:
                await asyncio.sleep(3.5)
            if GlobalStack.auto_zar == id_enemy:
                return
            
            if Settings.auto_infecter_chat != 'False':
                chat_answer = int(Settings.auto_infecter_chat)
            
            if '-' in Settings.auto_infecter_time:
                ai_time = random.randint(int(Settings.auto_infecter_time.split('-')[0]), int(Settings.auto_infecter_time.split('-')[1]))
            else:
                ai_time = int(Settings.auto_infecter_time)
            
            ai_percent = int(Settings.auto_infecter_percent)
            
            if exp_do == 0 or (((exp_int - exp_do) / exp_do) * 100) >= ai_percent:
                GlobalStack.auto_zar == id_enemy
                GlobalStack.stop = True
                try:
                    if exp_do == 0:
                        await asyncio.sleep(ai_time)
                        if id_enemy in VictimsEclusionRead.js_read or func.check_infect_time(id_enemy, JsRead.js_read) or int(id_enemy) == Me.me.id:
                            GlobalStack.stop = False
                            GlobalStack.auto_zar = False
                            return
                        temp = await app.send_message(chat_answer, f'Заразить @{id_enemy}')
                    else:
                        if (((exp_int - exp_do) / exp_do) * 100) >= ai_percent:
                            await asyncio.sleep(ai_time)
                            if id_enemy in VictimsEclusionRead.js_read or func.check_infect_time(id_enemy, JsRead.js_read) or int(id_enemy) == Me.me.id:
                                GlobalStack.stop = False
                                GlobalStack.auto_zar = False
                                return
                            temp = await app.send_message(chat_answer, f'Заразить @{id_enemy}')
                except RandomIdDuplicate:
                    pass
                else:
                    await asyncio.sleep(3)
                    
                    async for msg_ in app.search_messages(msg.chat.id, limit = 3):
                        if msg_.id > temp.id:
                            if msg_.text and '🤒 У вас горячка, вызванная' in msg_.text:
                                await app.send_message(msg.chat.id, '!купить вакцину')
                                await asyncio.sleep(random.randrange(3, 8))
                                await app.send_message(msg.chat.id, f'Заразить @{id_enemy}')
                                break
                            elif msg_.text and 'Антитела смогли справиться с заражением.' in msg_.text:
                                name = re.split('(🥽 Иммунитет объекта «|» оказался стойким к вашему патогену)', msg_.text)[2]
                                if id_enemy not in VictimsEclusionRead.js_read:
                                    func.victims_exclusion_append({id_enemy: {'name': name}}, victims_exclusion)
                                break
                            elif msg_.text and 'Антитела смогли справиться с заражением.' in msg_.text:
                                name = re.split('(💢 Попытка заразить | провалилась...)', msg_.text)[2]
                                if id_enemy not in VictimsEclusionRead.js_read:
                                    func.victims_exclusion_append({id_enemy: {'name': name}}, victims_exclusion)
                                break
                
                GlobalStack.stop = False
                GlobalStack.auto_zar = False
        else:
            bio_entity = f'<a href="tg://openmessage?user_id={id_enemy}">{name_enemy}</a>'
            infect_time = func.infect_time_get()
            thanks = ''
            infect_plus = False
            
            exp_do = (float(exp_do.replace(',', '.').replace('k', '')) * 1000 if 'k' in exp_do else int(exp_do))
            exp_int = (float(exp.replace(',', '.').replace('k', '')) * 1000 if 'k' in exp else int(exp))
            exp_plus = (exp_int if exp_do == 0 else exp_int - exp_do)
            if exp_plus >= 0:
                infect_plus = True
            if '-' not in str(exp_plus):
                exp_plus = f'+{exp_plus}'
            min_plus_sign = str(exp_plus)[0]
            exp_plus = float(str(exp_plus)[1:])
            if exp_plus >= 1000:
                exp_plus = str(int(round(exp_plus) / 1000)).replace('.', ',') + 'k'
            else:
                exp_plus = str(round(exp_plus))
            exp_plus = f'{min_plus_sign}{exp_plus}'
            
            text_thanks1 = random.choice(StyleTexts.zar_text_funny) if infect_plus else random.choice(StyleTexts.zar_text_crying)
            emoji_thanks1 = (random.choice(Style.premium_hearts_funny) if infect_plus else random.choice(Style.premium_hearts_cry)) if Me.me.is_premium else random.choice(Style.hearts)
            
            reaction_emoji = (emoji_thanks1 if Me.me.is_premium else random.choice(Style.reactions_hearts))
            
            if Settings.infect_thanks:
                thanks = (
                    f'<b><i>{text_thanks1} '
                    f'{emoji_thanks1}</i></b>'
                )
            
            emoji1 = (random.choice(Style.premium_zar) if Settings.infect_thanks and Me.me.is_premium else (random.choice(Style.premium_zar) if Me.me.is_premium else Style.zap_heart))
            emoji2 = (Style.prem_nom_writing if Me.me.is_premium else Style.bio_resource)
            
            # send message
            text = (
                f'{emoji1} <code>Заразить @{id_enemy}</code>\n'
                f'{emoji2} <b>{exp_plus}</b> {bio_entity}\n'
                f'{thanks}'
            )
            
            if Settings.visual_victims:
                await me_msg.edit_text(text)
            if Settings.infect_reaction:
                await asyncio.sleep(0.2)
                if Me.me.is_premium:
                    await app.invoke(
                        SendReaction(
                            peer = await app.resolve_peer(msg.chat.id),
                            msg_id = msg.id,
                            add_to_recent = False,
                            reaction = [
                                ReactionCustomEmoji(
                                document_id = int(''.join([d for d in reaction_emoji if d.isdigit()]))
                            )
                            ]
                        )
                    )
                else:
                    await app.send_reaction(msg.chat.id, msg.id, reaction_emoji)
            
            
            # write to zarlist
            victims_db = {id_enemy: {
                'experience': exp,
                'ot_data': ot_data,
                'name': name_enemy,
                'infect_time': infect_time
            }}
            if us_enemy:
                victims_db[id_enemy]['username'] = us_enemy
                victims_db[id_enemy]['name'] = name_enemy
                victims_db[id_enemy]['infect_time'] = infect_time
            
            func.json_append(victims_db, victims_file)
            JsRead.reload(refresh=True)

##

# Lab write
@app.on_message(filters.text & filters.user(all_iris), group = 104)
async def my_lab(app: Client, msg: Message):
    
    if '🔬 Досье лаборатории' in msg.text.splitlines()[0]:
        read = func.json_read(js_info)
        skills = {
            'pathogen_name': None,
            'ready_pathogens': None,
            'scientist_qualification': None,
            'infectivity': None,
            'immunity': None,
            'lethality': None,
            'security_service': None
        }
        for i in msg.text.html.splitlines():
            ispl = i.split(' ')
            if i.startswith('Руководитель: '):
                url = func.tag_get(i)
                if url.isdigit():
                    if url != str(Me.me.id):
                        return
                else:
                    if Me.me.username:
                        if url.lower() != Me.me.username.lower():
                            return
                    else:
                        return
            if ispl[0] == '🏷':
                skills['pathogen_name'] = ' '.join(ispl[3:])
            if ispl[0] == '🧪':
                skills['ready_pathogens'] = f'{ispl[3:][0]}/{ispl[3:][2]}'
            if ispl[0] == '👨‍🔬':
                skills['scientist_qualification'] = ispl[3:][0]
            if ispl[0] == '🦠':
                skills['infectivity'] = ispl[2:][0]
            if ispl[0] == '🛡':
                skills['immunity'] = ispl[2:][0]
            if ispl[0] == '☠️':
                skills['lethality'] = ispl[2:][0]
            if ispl[0] == '🕵️‍♂️':
                skills['security_service'] = ispl[3:][0]
        
        read.update(skills)
        
        with open(js_info, 'w', encoding='utf-8') as fw:
            json.dump(read, fw, indent=4)
        
        func.edit_cf(f_config, 'user_settings', 'me_inf', 'True')
        me_inf.refresh()


async def lab_victims_get():
    while True:
        await asyncio.sleep(60*60)
        today = datetime.utcnow()
        if today.time() > datetime.strptime('21:15:00', '%H:%M:%S').time() and today.time() < datetime.strptime('21:28:00', '%H:%M:%S').time():
            mesg = None
            while True:
                temp = await app.send_message(black_iris, 'Моя лаборатория')
                await asyncio.sleep(3)
                async for msg in app.search_messages(black_iris, limit = 3):
                    if '🔬 Досье лаборатории' in msg.text.splitlines()[0]:
                        mesg = msg
                        await msg.delete()
                        break
                await temp.delete()
                if mesg:
                    break
            await asyncio.sleep(3)
            msg = mesg
            read = func.json_read(js_info)
            for i in msg.text.html.split('\n'):
                ispl = i.split(' ')
                if i.startswith('Руководитель: '):
                    url = func.tag_get(i)
                    if url.isdigit():
                        if url != str(Me.me.id):
                            return
                    else:
                        if Me.me.username:
                            if url.lower() != (Me.me.username).lower():
                                return
                        else:
                            return
                if ispl[0] == '🧬':
                    read['bio-resources'] = ispl[2]
            
            func.json_write(js_info, read)
            me_inf.refresh()
            
            # await asyncio.sleep(60*20)
            
            # mesg = None
            # while True:
            #     temp = await app.send_message(black_iris, 'Моя лаборатория')
            #     await asyncio.sleep(3)
            #     async for msg in app.search_messages(black_iris, limit = 3):
            #         if '🔬 Досье лаборатории' in msg.text.split('\n')[0]:
            #             mesg = msg
            #             await msg.delete()
            #             break
            #     await temp.delete()
            #     if mesg:
            #         break
            # await asyncio.sleep(3)
            # msg = mesg
            # read = func.json_read(js_info)
            # for i in msg.text.html.split('\n'):
            #     ispl = i.split(' ')
            #     if i.startswith('Руководитель: '):
            #         url = func.tag_get(i)
            #         if url.isdigit():
            #             if url != str(Me.me.id):
            #                 return
            #         else:
            #             if Me.me.username:
            #                 if url.lower() != (Me.me.username).lower():
            #                     return
            #             else:
            #                 return
            #     if ispl[0] == '🧬':
            #         read['victims_food'] = humanize.intcomma(int(ispl[2].replace(',', '').replace('k', '')) - int((read['bio-resources']).replace(',', '').replace('k', '')))
            
            func.json_write(js_info, read)
            me_inf.refresh()
        
    
    

async def zarlist_auto():
    try:
        db_ready = False
        # check zarlist dates
        with open(victims_file, 'r', encoding='utf-8') as fr:
            js_read = json.load(fr)
        js_read_ = js_read.copy()
        today = datetime.today()
        for key, val in js_read.items():
            if key == str(Me.me.id):
                continue
            if key is None or not key.isdigit() or key == '0000' or val['ot_data'] == None or '@' in key or not 'k' in val['experience'] and '.' in val['experience'] or 'k' not in val['experience'] and int(val['experience']) < 35:
                js_read_.pop(key)
                continue
                z_date = datetime.strptime(val['infect_time'], '%d.%m.%Y %H:%M:%S')
                if z_date < today:
                    val.pop('infect_time')
                    js_read_[key] = val
            date = datetime.strptime(val['ot_data'], "%d.%m.%Y").date()
            if today.date() > date:
                js_read_.pop(key)
        with open(victims_file_dump, 'w', encoding='utf-8') as fw:
            json.dump(js_read_, fw, indent=4)
        db_ready = True
        
        JsRead.reload(refresh=True)
    except:
        pass
    else:
        os.remove(victims_file)
        shutil.copyfile(victims_file_dump, victims_file)

async def victims_dump():
    if os.path.exists(victims_file):
        shutil.copyfile(victims_file, victims_file_dump)


# write my my_illnesses
@app.on_message(filters.text & filters.regex(r'заражению') & filters.user(all_iris), group = 105)
async def illnesses_handler(app: Client, msg: Message):

    msgt = msg.text
    
    # Служба безопсности
    if msg.entities and '🕵️‍♂️ Служба безопасности' in msgt and re.findall(r'подвер[гла]+ заражению (неизвестным патогеном|патогеном)', msgt) and len(msg.entities) > 2 and msg.entities[1].type == enums.MessageEntityType.TEXT_LINK:
        if msg.entities[0].type == enums.MessageEntityType.TEXT_MENTION:
            if msg.entities[0].user and msg.entities[0].user.id == Me.me.id:
                if msg.entities[1].type == enums.MessageEntityType.TEXT_LINK:
                    enemy_url = func.tag_get(msg.entities[1].url)
                if 'неизвестным патогеном' in msgt:
                    pathogen_name = 'неизвестным патогеном'
                else:
                    pathogen_name = '\n'.join(msgt.split('\n')[4:]).rpartition('»')[0].partition('«')[2]
                if enemy_url in my_illnesses.illnesses:
                    my_illnesses.illnesses.pop(enemy_url)
                my_illnesses.illnesses[enemy_url] = f'«{pathogen_name}»'
                func.json_write(my_illnesses_file, my_illnesses.illnesses)
            
    # «Кто-то» не задететила СБ
    elif msg.entities and '🦠 Кто-то подверг заражению' in msgt and msg.entities[0].type == enums.MessageEntityType.TEXT_MENTION:
        if msg.entities[0].user and msg.entities[0].user.id == Me.me.id:
            if 'неизвестным патогеном' in msgt:
                pathogen_name = 'неизвестным патогеном'
            else:
                pathogen_name = msgt.rpartition('»')[0].partition('«')[2]
            if f'«{pathogen_name}»' in my_illnesses.illnesses:
                my_illnesses.illnesses.pop(f'«{pathogen_name}»')
            my_illnesses.illnesses[f'«{pathogen_name}»'] = None
            func.json_write(my_illnesses_file, my_illnesses.illnesses)



###

async def auto_zar_detecive(app: Client):
    
    while True:
        await asyncio.sleep(6.5)
        if '-' in Settings.auto_infecter_time:
            ai_time = random.randint(int(Settings.auto_infecter_time.split('-')[0]), int(Settings.auto_infecter_time.split('-')[1]))
        else:
            ai_time = int(Settings.auto_infecter_time)
        
        ai_percent = int(Settings.auto_infecter_percent)
        sync_chat = str(Settings.auto_infecter_chat_sync)
        if Settings.auto_infecter_sync:
            try:
                with open(js_detective_storage, 'r') as fr:
                    read = json.load(fr)
            except:
                continue
            for n in read.keys():
                for key, val in read[n].items():
                    exp = float(val['exp'].replace('k', '').replace(',', '.').replace(' ', '')) * 100
                    if key not in VictimsEclusionRead.js_read and (key not in JsRead.js_read or key in JsRead.js_read and not func.check_infect_time(key, JsRead.js_read)) and int(key) != Me.me.id:
                        my_exp = 0
                        if key in JsRead.js_read:
                            my_exp = (float(JsRead.js_read[key]['experience'].replace('k', '').replace(',', '.')) * 1000 if 'k' in JsRead.js_read[key]['experience'] else int(JsRead.js_read[key]['experience']))
                        if my_exp != 0 and exp > 35 and (((exp - my_exp) / my_exp) * 100) >= ai_percent:
                            while GlobalStack.stop:
                                await asyncio.sleep(3.5)
                            if GlobalStack.auto_zar == key:
                                continue
                            await asyncio.sleep(ai_time)
                            GlobalStack.auto_zar = key
                            GlobalStack.stop = True
                            temp = await app.send_message(sync_chat, f'Заразить @{key}')
            
                            await asyncio.sleep(3)
                            
                            async for msg_ in app.search_messages(sync_chat, limit = 3):
                                if msg_.id > temp.id:
                                    if msg_.text and '🤒 У вас горячка, вызванная' in msg_.text:
                                        await app.send_message(sync_chat, '!купить вакцину')
                                        await asyncio.sleep(random.randrange(5, 8))
                                        await app.send_message(sync_chat, f'Заразить @{key}')
                                        break
                                    elif msg_.text and 'Антитела смогли справиться с заражением.' in msg_.text:
                                        name = re.split('(🥽 Иммунитет объекта «|» оказался стойким к вашему патогену)', msg_.text)[2]
                                        if key not in VictimsEclusionRead.js_read:
                                            func.victims_exclusion_append({key: {'name': name}}, victims_exclusion)
                                        break
                                    elif msg_.text and 'Антитела смогли справиться с заражением.' in msg_.text:
                                        name = re.split('(💢 Попытка заразить | провалилась...)', msg_.text)[2]
                                        if key not in VictimsEclusionRead.js_read:
                                            func.victims_exclusion_append({key: {'name': name}}, victims_exclusion)
                                        break

                            
                            GlobalStack.stop = False
                            GlobalStack.auto_zar = False
                    





async def periodically_do():
    while True:
        asyncio.create_task(victims_dump())
        asyncio.create_task(zarlist_auto())
        await asyncio.sleep(60*30)

